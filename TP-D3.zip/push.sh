#!/bin/bash
git add --all
git commit -m "Update"
git push origin main
